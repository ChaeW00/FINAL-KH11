package com.kh.finalkh11.dto;

import lombok.Data;

@Data
public class MemberDto {
	private String memberId;
	private String memberPw;
	private String memberName;
	private String memberLevel;
	private String memberEmail;
	private String memberGender;
	private int memberManner;
	private String memberBirth;
	
}
