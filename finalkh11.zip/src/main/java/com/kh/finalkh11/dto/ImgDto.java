package com.kh.finalkh11.dto;

import lombok.Data;

@Data
public class ImgDto {
	public long imgNo;
	public String imgName;
	public String imgType;
	public long imgSize;
}
